//
//  PhotoCellTableViewCell.swift
//  tumblrfeed
//
//  Created by Swapnil Tamrakar on 1/31/17.
//  Copyright © 2017 Swapnil Tamrakar. All rights reserved.
//

import UIKit

class PhotoCellTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
